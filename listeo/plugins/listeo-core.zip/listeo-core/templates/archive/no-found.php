<div id="listeo-listings-container">
							<div class="loader-ajax-container" style=""> <div class="loader-ajax"></div> </div>
<section id="listings-not-found" class="margin-bottom-50 col-md-12">
	<h2><?php esc_html_e('Nothing found','listeo_core'); ?></h2>
	<p><?php _e( 'We&rsquo;re sorry but we do not have any listings matching your search, try to change you search settings', 'listeo_core' ); ?></p>
</section>
</div>